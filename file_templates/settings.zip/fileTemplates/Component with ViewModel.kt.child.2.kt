package //TODO()

data class ${NAME}State(
    
)