package //TODO()

sealed interface ${NAME}Event {
    object SampleEvent : ${NAME}Event
    data class SampleEventWithData(val data: Unit) : ${NAME}Event
}
